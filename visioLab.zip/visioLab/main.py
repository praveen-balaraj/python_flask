# https://www.roytuts.com/python-rest-api-crud-example-using-flask-and-mysql/


import pymysql
from app import app
from db_config import mysql
from flask import jsonify
from flask import flash, request
# from werkzeug import generate_password_hash, check_password_hash
		
		
@app.route('/orders', methods=['get'])
def orders():
	displayId = request.args.get('displayId', 1)
	try:
		conn = mysql.connect()
		cursor = conn.cursor(pymysql.cursors.DictCursor)
		
		cursor.execute("select dish_names, ordered_date from visiolab.order_details where jetson_id = "+
			"(select jetson_id from visiolab.customer_counter where display_id='"+displayId+"')"+
			"and transaction_complete = '0';")
		rowsDishName = cursor.fetchall()
		if len(rowsDishName)>0:
			print(rowsDishName[0]['dish_names'])
			cursor.execute("select *   from visiolab.food_details where "+
			"customer_id = (select customer_id from visiolab.customer_counter where display_id='"+displayId+"') and dish_name in "+
			"("+rowsDishName[0]['dish_names']+")")
			rowsFood = cursor.fetchall()
			print(rowsFood)
			rows = {'data':rowsFood}
			rows.update({'ordered_date':rowsDishName[0]['ordered_date']})
			rows.update({'totalRecords':len(rowsFood)})
			resp = jsonify(rows)
		else: 
			rows = {'data':{}}
			rows.update({'totalRecords':0})
			resp = jsonify(rows)
		
		resp.status_code = 200
		
		resp.headers.add('Access-Control-Allow-Origin', '*')
		return resp
	except Exception as e:
		print(e)
	finally:
		cursor.close() 
		conn.close()

@app.route('/order/update', methods=['PUT'])
def update_order():
	try:	
		_json = request.json
		_display_id = _json['displayId']

		sql = "update visiolab.order_details set transaction_complete = 1 where jetson_id = (select jetson_id from visiolab.customer_counter where display_id=%s) "
		print(_display_id)
		data = (_display_id)
		conn = mysql.connect()
		cursor = conn.cursor()
		cursor.execute(sql, data)
		conn.commit()
		rows = {'message': "Record updated successfully"}
		rows.update({'status_code':200})
		res = jsonify(rows)
		
		return res
	except Exception as e:
		print(e)
	finally:
		cursor.close() 
		conn.close()

@app.errorhandler(404)
def not_found(error=None):
    message = {
        'status': 404,
        'message': 'Not Found: ' + request.url,
    }
    resp = jsonify(message)
    resp.status_code = 404

    return resp
		
if __name__ == "__main__":
    app.run(port=8080)