from app import app
from flaskext.mysql import MySQL

mysql = MySQL()
 
# MySQL configurations
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'VisioLab2020'
app.config['MYSQL_DATABASE_DB'] = 'visiolab'
app.config['MYSQL_DATABASE_HOST'] = '34.89.87.100'
mysql.init_app(app)